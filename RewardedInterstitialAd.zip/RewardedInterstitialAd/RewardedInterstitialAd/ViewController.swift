//
//  ViewController.swift
//  RewardedInterstitialAd
//
//  Created by MacBook Pro on 23/04/2024.
//

import UIKit
import GoogleMobileAds

class ViewController: UIViewController {

    private var rewardedInterstitialAd: GADRewardedInterstitialAd?
    
    private var coinCount = 0
    
    @IBOutlet weak var showRewardedInterstitialAd: UIButton!
    @IBOutlet weak var coinCountLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        addloadrewardedInterstitialAd()
        
    }
    
    @IBAction func showRewardedInterstitialAd(_ sender: AnyObject) {
        if let ad = self.rewardedInterstitialAd {
            ad.present(fromRootViewController: self) {
                let reward = ad.adReward
                print("Reward received with currency \(reward.amount), amount \(reward.amount.doubleValue)")
                self.earnCoins(reward.amount.intValue)
            }
        } else {
            print("Ad wasn't ready")
        }
    }


}
extension ViewController : GADFullScreenContentDelegate {
    
    func addloadrewardedInterstitialAd() {
        GADRewardedInterstitialAd.load(withAdUnitID:"ca-app-pub-3940256099942544/6978759866",
                                       request: GADRequest()) { ad, error in
            if let error = error {
                return print("Failed to load rewarded interstitial ad with error: \(error.localizedDescription)")
            }
            
            self.rewardedInterstitialAd = ad
            self.rewardedInterstitialAd?.fullScreenContentDelegate = self
        }
        
    }
    private func earnCoins(_ coins: NSInteger) {
        coinCount += coins
        coinCountLabel.text = "Coins: \(self.coinCount)"
    }
    
    
}

